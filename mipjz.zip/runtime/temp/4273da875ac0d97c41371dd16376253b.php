<?php if (!defined('THINK_PATH')) exit(); /*a:0:{}*/ ?>

<template>
	<div>
		
<header class="mipcms-container-header">

    <div class="float-left">

        <h4><?php echo $itemName; ?>管理</h4>

    </div>

</header>

<main class="mipcms-container-body" style="height: calc(100% - 50px)">

<div class="row">

    <div class="col-md-6">

    <section class="mip-box">

        <section class="mip-box-body">

            <i-form ref="form" :model="form" :label-width="100" :rules="rules">

                <Form-item label="原密码" prop="oldPassword">

                    <i-Input  type="password" v-model="form.oldPassword" placeholder="原密码"></i-Input>

                </Form-item>

                <Form-item label="新密码" prop="newPassword">

                    <i-Input v-model="form.newPassword" type="password" placeholder="新密码"></i-Input>

                </Form-item>

                <Form-item label="确认密码" prop="rpassword">

                    <i-Input v-model="form.rpassword" type="password" placeholder="确认密码"></i-Input>

                </Form-item>

                <Form-item >

                    <i-Button type="primary" @click='passwordSave("form")'>保存</i-Button>

                </Form-item>

                

            </i-form>

        </section>

    </section>

    </div>

</div>

</main>
	</div>
</template><script>    export default {
     data () {
       return {
            itemName: '<?php echo $itemName; ?>',
            form: {
                oldPassword: '',
                newPassword: '',
                rpassword: '',
            },
            rules: {
                oldPassword: [{
                        required: true,
                        message: '请输入密码',
                        trigger: 'blur'
                    },
                ],
                newPassword: [{
                        required: true,
                        message: '请输入新密码',
                        trigger: 'blur'
                    },
                ],
                rpassword: [{
                        required: true,
                        message: '请输入密码',
                        trigger: 'blur'
                    },
                ],

            },
           }
     },
    watch: {
         
    },
    mounted() {
    },
    methods: {
        passwordSave(formName) {
            this.$refs[formName].validate((valid) => {
                if(valid) {
                    let _this = this;
                    this.$mip.ajax('<?php echo $domain; ?>/user/ApiUserUser/userPasswordEdit', {
                        oldPassword: md5(_this.form.oldPassword),
                        newPassword: md5(_this.form.newPassword),
                        rpassword: md5(_this.form.rpassword),
                    }).then(function(res) {
                        if(res.code == 1) {
                            _this.$Message.success('修改成功');
                            location.href = '<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/login';
                        }
                    });
                } else {
                    return false;
                }
            });
        }
    }
}
  </script>