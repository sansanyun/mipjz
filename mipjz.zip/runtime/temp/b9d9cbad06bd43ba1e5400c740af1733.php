<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:76:"/Users/guuyang/web/wwwroot/mipjz/template/default/article/articleDetail.html";i:1546006453;s:64:"/Users/guuyang/web/wwwroot/mipjz/template/default/main/main.html";i:1546007770;s:66:"/Users/guuyang/web/wwwroot/mipjz/template/default/main/header.html";i:1546011585;s:73:"/Users/guuyang/web/wwwroot/mipjz/template/default/block/article-list.html";i:1546392862;s:69:"/Users/guuyang/web/wwwroot/mipjz/template/default/block/tags-new.html";i:1546006453;s:66:"/Users/guuyang/web/wwwroot/mipjz/template/default/main/footer.html";i:1546006453;}*/ ?>
<!DOCTYPE html>
<html mip>
<head>
    <meta charset="utf-8">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="MobileOptimized" content="width"/>
    <meta name="HandheldFriendly" content="true"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
    <link rel="shortcut icon" href="<?php echo $domainStatic; ?>/favicon.ico" type="image/x-icon" />
    <title><?php echo $mipTitle; ?></title>

    <meta name="keywords" content="<?php echo $mipKeywords; ?>">
    <meta name="description" content="<?php echo $mipDescription; ?>">
    
<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo $mipTitle; ?>" />
<meta property="og:description" content="<?php echo $mipDescription; ?>" />
<meta property="og:image" content="<?php echo $itemInfo['firstImg']; ?>" />
<meta property="og:release_date" content="<?php echo date('Y-m-d',$itemInfo['publish_time']); ?>" />

    <link rel="stylesheet" type="text/css" href="https://c.mipcdn.com/static/v1/mip.css">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/<?php echo $tplName; ?>/css/mipcms.css">
    <style mip-custom>
        .search-form div{
            width: 250px;
        }
        .mipmb-default-search {
            margin-top: -4px;
        }
    
.mipcms-detail-body img{
    width: auto;
    min-width: auto;
    height: auto; 
}
    

    </style>
    <link rel="canonical" href="<?php echo $siteUrl; ?>">
</head>
<body>
<?php if($mipInfo["guanfanghaoStatus"]): ?><?php echo $mipInfo['guanfanghaoCambrian']; endif; ?>
    <mip-fixed type="top">
    <div class="mipmb-header mipmb-header-default" id="mip_header">
    <div class="container">
        <div class="menu-warp">
            <div class="logo-text">
                <a data-type="mip" href="<?php echo $domain; ?>" data-title="<?php echo $mipInfo['siteName']; ?>"><?php echo $mipInfo['siteName']; ?></a>
            </div>
            <ul class="mipmb-menu list-unstyled">
                <li class='nav-item <?php if($mod=='index'): ?>active<?php endif; ?>'>
                    <a href="<?php echo $domain; ?>" data-type="mip" data-title="<?php echo $siteInfo['siteName']; ?>" title='首页'>首页</a>
                </li>
                <?php $__think__tag__ = '{"value":"v","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.widget.model.Widget")->getItemListByTag($__think__tag__); if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                <li class="nav-item">
                    <a <?php if($v["target"]): ?>target="_blank"<?php endif; ?> href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <div class="d-none d-lg-block header-search-warp">
                <mip-form class='form-inline search-form' width='350' url="<?php echo $domain; ?>/search" method="get">
                    <div class="d-inline-block pull-left">
                        <input class="form-control" type="text" name="q">
                    </div>
                    <input type="submit" class="d-inline btn btn-primary" value="搜索">
                </mip-form>
            </div>
        </div>
        <div class="d-none d-lg-block float-right">
            <ul class="mipmb-menu list-unstyled">
                <?php if($userInfo["group_id"] == 1): ?>
                <li>
                    <a href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/">后台管理</a>
                </li>
                <?php else: ?>
                <li>
                    <a href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/">登录</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

    </mip-fixed>
    <main class="mipcms-main">
    
<div class="container">
    <?php $__think__tag__ = '{"isHome":"1","cid":"'.$itemInfo['cid'].'","ulClass":"breadcrumb p-0 bg-transparent","liClass":"breadcrumb-item","separator":""}';$__think__info__ = "";$__think__info__ = model("app.article.model.Articles")->getCrumb($__think__tag__);echo $__think__info__; ?>
</div>
<div class="container">
    <div class="row">
        <main class="col-lg-8">
            <section class="mip-box mip-box-main">
                <section class="mip-box-heading">
                     <h1 class="detail-title"><?php echo $itemInfo['title']; ?></h1>
                     <div class="info clearfix">
                        <ul>
                            <li>时间:<time><?php echo date('Y-m-d H:i:s',$itemInfo['publish_time']); ?></time></li>
                            <li>浏览:<?php echo $itemInfo['views']; ?></li>
                            <li>来源:<?php echo $mipInfo['siteName']; ?></li>
                        </ul>
                        <?php if($tags): ?>
                        <ul class="tags hidden-xs pull-right">
                            <?php if(is_array($tags) || $tags instanceof \think\Collection || $tags instanceof \think\Paginator): if( count($tags)==0 ) : echo "" ;else: foreach($tags as $key=>$v): ?>
                            <li><a href="<?php echo $v['url']; ?>" data-type="mip" data-title="<?php echo $v['tags']['name']; ?>" title="<?php echo $v['tags']['name']; ?>" ><?php echo $v['tags']['name']; ?></a></li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                </section>
                <section class="mip-box-body mipcms-detail-body">
                	<?php echo hook('adHook','detailContentTop'); ?>
                    <?php echo $itemInfo['mipContent']; if($mipInfo['articlePages']): ?>
                    <div class="mip-page-pagination text-center">
                        <ul class="pagination list-unstyled">
                            <?php echo $itemInfo['pageCode']; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                	<?php echo hook('adHook','detailContentBottom'); ?>
                    <p>猜你喜欢</p>
                    <div class="mipui-widget-media-body mipui-category-list-001">
                        <?php $__think__tag__ = '{"value":"v","keywords":"'.$itemInfo['tagsListString'].'","notUuids":"'.$itemInfo['uuid'].'","limit":"5","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.article.model.Articles")->getItemListByTag($__think__tag__,"list");$pagination = ""; if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                            <div class="mipui-category-list-item">
    <div class="item-media">
        <a href="<?php echo $v['url']; ?>" class="item-link" data-type="mip" data-title="<?php echo $v['title']; ?>" title='<?php echo $v['title']; ?>'>
            <?php if($v['firstImg']): ?>
            <mip-img layout="container" alt='<?php echo $v['title']; ?>' src="<?php echo $v['firstImg']; ?>"></mip-img>
            <?php else: ?>
            <mip-img layout="container" src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/<?php echo $tplName; ?>/images/no-images.jpg" alt='<?php echo $v['title']; ?>'></mip-img>
            <?php endif; ?>
        </a>
    </div>
    <div class="item-content">
        <h4><a href="<?php echo $v['url']; ?>" data-type="mip" data-title="<?php echo $v['title']; ?>" title='<?php echo $v['title']; ?>'><?php echo $v['title']; ?></a></h4>
        <p class="description"><?php echo $v['description']; ?></p>
        <p>
            <span><?php echo date('Y-m-d',$v['publish_time']); ?></span>
        </p>
    </div>
</div>

                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </div>
                    <div class="mip-box-footer item-up-down-page ">
                        <ul class="clearfix list-unstyled">
                            <?php $__think__tag__ = '{"value":"val","limit":"1","itemId":"'.$itemInfo['id'].'","type":"detail","itemType":"upPage","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.article.model.Articles")->getPage($__think__tag__); if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($index % 2 );++$index;?>
                            <div class="mipmb-page-item item-up-page">
                                <p>上一篇</p>
                                <a href="<?php echo $val['url']; ?>"><?php echo $val['title']; ?></a>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; $__think__tag__ = '{"value":"val","limit":"1","itemId":"'.$itemInfo['id'].'","type":"detail","itemType":"downPage","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.article.model.Articles")->getPage($__think__tag__); if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($index % 2 );++$index;?>
                            <div class="mipmb-page-item item-down-page ">
                                <p>下一篇</p>
                                <a href="<?php echo $val['url']; ?>"><?php echo $val['title']; ?></a>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                </section>
                
            </section>
            
        </main>
        <aside class="col-lg-4 hidden-xs">
            <?php echo hook('adHook','detailSideA'); ?>
            <section class="mip-box mip-box-default">
                <section class="mip-box-heading">
                    <h3>最新<?php echo $mipInfo['articleModelName']; ?></h3>
                </section>
                <section class="mip-box-body">
                    <ul class="list-unstyled">
                        <?php $__think__tag__ = '{"value":"v","limit":"5","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.article.model.Articles")->getItemListByTag($__think__tag__,"list");$pagination = ""; if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                        <li class="li-box-list">
                            <a href="<?php echo $v['url']; ?>" data-type="mip" data-title="<?php echo $v['title']; ?>" title="<?php echo $v['title']; ?>"><?php echo $v['title']; ?></a>
                            <p><?php echo date('Y-m-d',$v['publish_time']); ?></p>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </section>
            </section>
            <?php echo hook('adHook','detailSideB'); ?>
            <div class="mip-box">
    <div class="mip-box-heading">
        <h3 class="title">最新<?php echo $mipInfo['tagModelName']; ?></h3>
    </div>
    <div class="mip-box-body">
        <ul class="list-unstyled tags">
            <?php $__think__tag__ = '{"value":"v","limit":"20","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.tag.model.Tags")->getItemListByTag($__think__tag__,"list");$pagination = ""; if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                <li class="m-b-sm"><a href="<?php echo $v['url']; ?>" data-type="mip" data-title="<?php echo $v['name']; ?>" title="<?php echo $v['name']; ?>"><?php echo $v['name']; ?></a></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

        </aside>

    </div>
</div>

    </main>
    <footer class="mipui-footer">
    <div class="container">
        <?php echo hook("friendlinkHook"); ?>
        <p class="text-center mip-footer">&copy;<?php echo date('Y'); ?> <a data-type="mip" href="<?php echo $domain; ?>" data-title="<?php echo $mipInfo['siteName']; ?>"><?php echo $mipInfo['siteName']; ?></a> <?php echo $mipInfo['icp']; ?><a href="<?php echo $domain; ?>/sitemap.xml">网站地图</a> <br class="visible-xs" /> Powered By <a data-type="mip" data-title='MIPCMS'  href="http://www.mipcms.com" target="_blank">MIPCMS</a><?php echo $mipInfo['statistical']; ?> </p>
    </div>
</footer>
    <mip-fixed type="gototop">
        <mip-gototop></mip-gototop>
    </mip-fixed>
    
<?php if($mipInfo["guanfanghaoStatus"]): ?>
<script type="application/ld+json">
{
    "@context": "https://zhanzhang.baidu.com/contexts/cambrian.jsonld",
    "@id": "<?php echo $currentUrl; ?>",
    "title":"<?php echo $itemInfo['title']; ?>",
        <?php preg_match_all('/<mip-img.*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>*<\/mip-img>/', $itemInfo['mipContent'], $matches); if(count($matches)){$first_img = @$matches [1][0]; $two_img = @$matches [1][1]; $three_img = @$matches [1][2]; if($three_img){?>
            "images": ["<?php echo $first_img ;?>","<?php echo $two_img ;?>","<?php echo $three_img ;?>"],
             <?php } else {if($first_img){?>  
                    "images": ["<?php echo $first_img ;?>"],
                 <?php } else {if ($itemInfo['img_url']) {?>
                    "images": ["<?php echo $domain . $itemInfo['img_url'] ;?>"],
                    <?php }}}}?>
    "description": "<?php echo $mipDescription; ?>",
    "pubDate": "<?php echo date('Y-m-d',$itemInfo['publish_time']); ?>T<?php echo date('H:i:s',$itemInfo['publish_time']); ?>",
    "isOriginal": "1"
}
</script>
<?php endif; ?>

    <script src="https://c.mipcdn.com/static/v1/mip.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-stats-baidu/mip-stats-baidu.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-gototop/mip-gototop.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-history/mip-history.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-fixed/mip-fixed.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/extensions/platform/v1/mip-cambrian/mip-cambrian.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-form/mip-form.js" type="text/javascript" charset="utf-8"></script>
    

</body>
</html>