<?php if (!defined('THINK_PATH')) exit(); /*a:0:{}*/ ?>
<style>

</style>
<template>
<div>
    <header class="mipcms-container-header clearfix">
        <div class="header-group">
            <h4 class="title">插件</h4> <h5 class="sub-title">清除缓存</h5>
        </div>
    </header>
    <main class="mipcms-container-body" style="height: calc(100% - 50px)">
            <div class="row">
            	<div class="col-3">
		            <section class="mip-box">
		                <section class="mip-box-body text-center">
							<p>缓存文件</p>
		                     <button class="ivu-btn ivu-btn-primary" @click="indexAction">一键清理</button>
		                </section>
		            </section>
            	</div>
            </div>
         
    </main>   
    
</div>
</template>

<script>
    export default {
     data () {
       return {
       }
    },
        watch: {
        },
        mounted() {
        },
        methods: {
        	indexAction() {
                this.$mip.ajax('<?php echo $domain; ?>/clear/ApiAdminClear/index', {

                }).then(res => {
                    if(res.code == 1) {
                 		this.$Message.success('操作成功');
                    }
                });
        	}, 
        	
        }
    }
</script>
