<?php if (!defined('THINK_PATH')) exit(); /*a:0:{}*/ ?>
<li class="li has-sub one-list" :class='{"active":$route.params.mod  == ""}'>
 	<router-link class="list-link" to="/"><i class="ion-ios-home-outline"></i> 首页</router-link>
</li>
