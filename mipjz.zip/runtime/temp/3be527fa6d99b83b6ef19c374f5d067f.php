<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:50:"D:\wwwroot\mipjz\template\default\index\index.html";i:1546006454;s:48:"D:\wwwroot\mipjz\template\default\main\main.html";i:1546007770;s:50:"D:\wwwroot\mipjz\template\default\main\header.html";i:1546011586;s:53:"D:\wwwroot\mipjz\template\default\block\tags-hot.html";i:1546006454;s:50:"D:\wwwroot\mipjz\template\default\main\footer.html";i:1546006454;}*/ ?>
<!DOCTYPE html>
<html mip>
<head>
    <meta charset="utf-8">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="MobileOptimized" content="width"/>
    <meta name="HandheldFriendly" content="true"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
    <link rel="shortcut icon" href="<?php echo $domainStatic; ?>/favicon.ico" type="image/x-icon" />
    <title><?php echo $mipTitle; ?></title>

    <meta name="keywords" content="<?php echo $mipKeywords; ?>">
    <meta name="description" content="<?php echo $mipDescription; ?>">
    
    
    <link rel="stylesheet" type="text/css" href="https://c.mipcdn.com/static/v1/mip.css">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/<?php echo $tplName; ?>/css/mipcms.css">
    <style mip-custom>
        .search-form div{
            width: 250px;
        }
        .mipmb-default-search {
            margin-top: -4px;
        }
    
    </style>
    <link rel="canonical" href="<?php echo $siteUrl; ?>">
</head>
<body>
<?php if($mipInfo["guanfanghaoStatus"]): ?><?php echo $mipInfo['guanfanghaoCambrian']; endif; ?>
    <mip-fixed type="top">
    <div class="mipmb-header mipmb-header-default" id="mip_header">
    <div class="container">
        <div class="menu-warp">
            <div class="logo-text">
                <a data-type="mip" href="<?php echo $domain; ?>" data-title="<?php echo $mipInfo['siteName']; ?>"><?php echo $mipInfo['siteName']; ?></a>
            </div>
            <ul class="mipmb-menu list-unstyled">
                <li class='nav-item <?php if($mod=='index'): ?>active<?php endif; ?>'>
                    <a href="<?php echo $domain; ?>" data-type="mip" data-title="<?php echo $siteInfo['siteName']; ?>" title='首页'>首页</a>
                </li>
                <?php $__think__tag__ = '{"value":"v","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.widget.model.Widget")->getItemListByTag($__think__tag__); if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                <li class="nav-item">
                    <a <?php if($v["target"]): ?>target="_blank"<?php endif; ?> href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <div class="d-none d-lg-block header-search-warp">
                <mip-form class='form-inline search-form' width='350' url="<?php echo $domain; ?>/search" method="get">
                    <div class="d-inline-block pull-left">
                        <input class="form-control" type="text" name="q">
                    </div>
                    <input type="submit" class="d-inline btn btn-primary" value="搜索">
                </mip-form>
            </div>
        </div>
        <div class="d-none d-lg-block float-right">
            <ul class="mipmb-menu list-unstyled">
                <?php if($userInfo["group_id"] == 1): ?>
                <li>
                    <a href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/">后台管理</a>
                </li>
                <?php else: ?>
                <li>
                    <a href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/">登录</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

    </mip-fixed>
    <main class="mipcms-main">
    
<?php $__think__tag__ = '{"value":"recommendList","where":"is_recommend = 1","limit":"4","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.article.model.Articles")->getItemListByTag($__think__tag__,"list");$recommendList = $__think__list__; if($recommendList && count($recommendList) > 3): ?>
<div class="container mb-3 d-none d-sm-block">
    <div class="row">
        <div class="col-lg-8">
            <div class="position-relative">
                <a href="<?php echo $recommendList[0]['url']; ?>" data-type="mip" data-title="<?php echo $recommendList[0]['title']; ?>" title="<?php echo $recommendList[0]['title']; ?>" class="mip-top-img image-link-left">
                    <mip-img
                            layout="full"
                            class="img left-img"
                            alt="<?php echo $recommendList[0]['title']; ?>"
                            src="<?php echo $recommendList[0]['firstImg']; ?>">
                    </mip-img>
                </a>
                <div class="caption w-100">
                    <time class="time" datetime="<?php echo date('Y-m-d',$recommendList[0]['publish_time'] ); ?>"><?php echo date('Y-m-d',$recommendList[0]['publish_time'] ); ?></time>
                    <h3><a href="<?php echo $recommendList[0]['url']; ?>" data-type="mip" data-title="<?php echo $recommendList[0]['title']; ?>"  title="<?php echo $recommendList[0]['title']; ?>"><?php echo $recommendList[0]['title']; ?></a></h3>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="mip-top-block mip-top-right mb-3">
                <a href="<?php echo $recommendList[1]['url']; ?>"   data-type="mip" data-title="<?php echo $recommendList[1]['title']; ?>" title="<?php echo $recommendList[1]['title']; ?>" class="mip-top-img image-link-right-top">
                    <mip-img
                        layout="full"
                        class="img right-img-top"
                        alt="<?php echo $recommendList[1]['title']; ?>"
                        src="<?php echo $recommendList[1]['firstImg']; ?>">
                    </mip-img>
                </a>
                <div class="caption">
                    <a href="<?php echo $recommendList[1]['url']; ?>"  data-type="mip" data-title="<?php echo $recommendList[1]['title']; ?>"  title="<?php echo $recommendList[1]['title']; ?>"><?php echo $recommendList[1]['title']; ?></a>
                </div>
            </div>
            <div class="d-flex justify-content-between">
                <div class="mip-top-block mip-top-right">
                    <a href="<?php echo $recommendList[2]['url']; ?>" data-type="mip" data-title="<?php echo $recommendList[2]['title']; ?>" title="<?php echo $recommendList[2]['title']; ?>" class="mip-top-img image-link-right-bottom">
                        <mip-img
                            layout="full"
                            class="img right-img-bottom"
                            alt="<?php echo $recommendList[2]['title']; ?>"
                            src="<?php echo $recommendList[2]['firstImg']; ?>">
                        </mip-img>
                    </a>
                    <div class="caption">
                        <a href="<?php echo $recommendList[2]['url']; ?>"  data-type="mip" data-title="<?php echo $recommendList[2]['title']; ?>" title="<?php echo $recommendList[2]['title']; ?>"><?php echo $recommendList[2]['title']; ?></a>
                    </div>
                </div>
                <div class="mip-top-block mip-top-right">
                    <a href="<?php echo $recommendList[3]['url']; ?>"  data-type="mip" data-title="<?php echo $recommendList[3]['title']; ?>" title="<?php echo $recommendList[3]['title']; ?>" class="mip-top-img image-link-right-bottom">
                        <mip-img
                            layout="full"
                            class="img right-img-bottom"
                            alt="<?php echo $recommendList[3]['title']; ?>"
                            src="<?php echo $recommendList[3]['firstImg']; ?>">
                        </mip-img>
                    </a>
                    <div class="caption">
                       <a href="<?php echo $recommendList[3]['url']; ?>"  data-type="mip" data-title="<?php echo $recommendList[3]['title']; ?>" title="<?php echo $recommendList[3]['title']; ?>"><?php echo $recommendList[3]['title']; ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="container">
    <div class="row">
        <main class="col-lg-8">
            <div class="row">
                <?php $__think__tag__ = '{"value":"v","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.article.model.ArticlesCategory")->getCategoryByTag($__think__tag__); if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                <section class="col-lg-6">
                    <section class="mip-box">
                        <section class="mip-box-heading">
                            <h3><?php echo $v['name']; ?></h3>
                        </section>
                        <section class="mip-box-body">
                            <ul class="list-unstyled clearfix">
                                <?php $__think__tag__ = '{"value":"val","cid":"'.$v['id'].'","limit":"5","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.article.model.Articles")->getItemListByTag($__think__tag__,"list");$pagination = ""; if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($index % 2 );++$index;?>
                                    <li class="list-time">
                                        <a href="<?php echo $val['url']; ?>" data-type="mip" data-title="<?php echo $val['title']; ?>" title="<?php echo $val['title']; ?>"><?php echo $val['title']; ?></a><time class="pull-right"><?php echo date('m-d',$val['publish_time']); ?></time>
                                    </li>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </ul>
                        </section>
                    </section>
                </section>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </main>
        <aside class="col-lg-4 hidden-xs">
        	<?php echo hook('adHook','indexSideA'); ?>
            <section class="mip-box mip-box-default">
                <section class="mip-box-heading">
                    <h3>热门<?php echo $mipInfo['articleModelName']; ?></h3>
                </section>
                <section class="mip-box-body">
                    <ul class="list-unstyled">
                        <?php $__think__tag__ = '{"value":"v","key":"k","orderBy":"views","limit":"6"}';$__think__list__ = "";$__think__list__ = model("app.article.model.Articles")->getItemListByTag($__think__tag__,"list");$pagination = ""; if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $k = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($k % 2 );++$k;?>
                        <li class="li-box-list">
                            <a href="<?php echo $v['url']; ?>" data-type="mip" data-title="<?php echo $v['title']; ?>" title="<?php echo $v['title']; ?>"><?php echo $v['title']; ?></a>
                            <p><?php echo date('Y-m-d',$v['publish_time']); ?></p>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </section>
            </section>
            <div class="mip-box">
    <div class="mip-box-heading">
        <h3 class="title">热门<?php echo $mipInfo['tagModelName']; ?></h3>
    </div>
    <div class="mip-box-body">
        <ul class="list-unstyled tags">
            <?php $__think__tag__ = '{"value":"v","orderBy":"relevance_num","limit":"20","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.tag.model.Tags")->getItemListByTag($__think__tag__,"list");$pagination = ""; if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                <li class="m-b-sm"><a href="<?php echo $v['url']; ?>" data-type="mip" data-title="<?php echo $v['name']; ?>" title="<?php echo $v['name']; ?>"><?php echo $v['name']; ?></a></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

        	<?php echo hook('adHook','indexSideB'); ?>
        </aside>

    </div>
</div>

    </main>
    <footer class="mipui-footer">
    <div class="container">
        <?php echo hook("friendlinkHook"); ?>
        <p class="text-center mip-footer">&copy;<?php echo date('Y'); ?> <a data-type="mip" href="<?php echo $domain; ?>" data-title="<?php echo $mipInfo['siteName']; ?>"><?php echo $mipInfo['siteName']; ?></a> <?php echo $mipInfo['icp']; ?><a href="<?php echo $domain; ?>/sitemap.xml">网站地图</a> <br class="visible-xs" /> Powered By <a data-type="mip" data-title='MIPCMS'  href="http://www.mipcms.com" target="_blank">MIPCMS</a><?php echo $mipInfo['statistical']; ?> </p>
    </div>
</footer>
    <mip-fixed type="gototop">
        <mip-gototop></mip-gototop>
    </mip-fixed>
    
    <script src="https://c.mipcdn.com/static/v1/mip.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-stats-baidu/mip-stats-baidu.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-gototop/mip-gototop.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-history/mip-history.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-fixed/mip-fixed.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/extensions/platform/v1/mip-cambrian/mip-cambrian.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-form/mip-form.js" type="text/javascript" charset="utf-8"></script>
    
</body>
</html>