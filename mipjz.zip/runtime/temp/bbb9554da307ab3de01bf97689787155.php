<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:43:"D:\wwwroot\mipjz/app/admin\view\.\main.html";i:1547480109;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
    <title><?php echo $siteInfo['siteName']; ?>管理后台</title>
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.staticfile.org/iview/3.0.1/styles/iview.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/admin/css/admin.css?v=<?php echo time(); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/componentcss"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/addons/addonscss"/>
    <style type="text/css">
      [v-cloak] {
        display: none;
        }
        .ivu-modal-close {
            z-index: 999;
        }
        .mip-container>div {
		    height: 100%;
		}
		
		.loding-circular {
		    width: 35px;
		    height: 35px;
		    animation: ani-demo-spin 1s linear infinite;
		}
		.loding-circular  .path {
		    animation: loading-dash 1.5s ease-in-out infinite;
		    stroke-dasharray: 90,150;
		    stroke-dashoffset: 0;
		    stroke-width: 2;
		    stroke: #20a0ff;
		    stroke-linecap: round;
		}

    </style>
    
        
    
</head>
<body class="mip-admin" >
    <section id="mipcms">
    	<header class="mip-header clearfix b-b">
	        <div class="mip-logo">
	            <div class="mip-logo-a"><a href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>">管理系统后台</a><span class="sub-v"></span></div>
	        </div>
	        <ul class="header-switch">
	            <li><a href="<?php echo $domainStatic; ?>" target="_blank" class="link"><Icon type="ios-home-outline"></Icon> 网站主页</a></li>
	            <li v-for='item in headerList'>
		            <router-link class="link" :to='"/addons/"+item.name+"/"+($route.params.dataId && ($route.params.dataId != "undefined")  ? $route.params.dataId : "")' v-text='item.title'></router-link>
		        </li>
	        </ul>
	        <div class="mip-user-info" v-cloak>
	            <ul class="nav navbar-nav navbar-right">
	                 <Dropdown trigger="click" >
	                    <a href="javascript:void(0)">
	                        管理员
	                        <Icon type="arrow-down-b"></Icon>
	                    </a>
	                    <Dropdown-Menu slot="list">
	                        <li class="ivu-dropdown-item" @click='editPassword'>修改密码</li>
	                        <li class="ivu-dropdown-item" @click='loginOut'>安全退出</li>
	                    </Dropdown-Menu>
	                </Dropdown>
	            </ul>
	        </div>
	    </header>
        <main class="mip-main clearfix" >
                <aside id="menu" class="mip-menu hidden-xs">
                   <div class="menu-wrap">
                        <div class="menu-content sidebar-menu">
                            <ul class="sidebar-list">
                                <?php if(is_array($AdminMenu) || $AdminMenu instanceof \think\Collection || $AdminMenu instanceof \think\Paginator): if( count($AdminMenu)==0 ) : echo "" ;else: foreach($AdminMenu as $key=>$v): if($v['html']): ?>
                                        <?php echo $v['html']; endif; endforeach; endif; else: echo "" ;endif; ?>
                            </ul>
                        </div>
                    </div>
                </aside>
                <section class="mip-container">
                    <router-view></router-view>
                </section>
          </main>
      
    </section>
    
</body>

<script type="text/javascript">
    var siteGlobal = {
        domain: '<?php echo $domain; ?>',
        rewrite: '<?php echo $rewrite; ?>',
        siteInfo: <?php echo $siteInfoToJson; ?>,
        mod: '<?php echo $mod; ?>',
        ctr: '<?php echo $ctr; ?>',
        act: '<?php echo $act; ?>',
    }
</script>


<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/common/js/components.js"></script>
<script src="https://cdn.staticfile.org/iview/3.0.1/iview.min.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/componentjs" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/addons/addonsjs" type="text/javascript" charset="utf-8"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/styles/simditor.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/styles/simditor-html.css"/>
<script src="https://cdn.staticfile.org/echarts/4.1.0.rc2/echarts.min.js"></script>
<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/scripts/jquery.min.js"></script>
<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/scripts/module.js"></script>
<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/scripts/hotkeys.js"></script>
<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/scripts/uploader.js"></script>
<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/scripts/simditor.js"></script>
<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/scripts/simditor-autosave.js"></script>
<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/scripts/beautify-html.js"></script>
<script src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/plugin/simditor/scripts/simditor-html.js"></script>
<script type="text/javascript">
	function randomNum(minNum, maxNum) {
        switch(arguments.length) {
            case 1:
                return parseInt(Math.random() * minNum + 1);
                break;
            case 2:
                return parseInt(Math.random() * (maxNum - minNum + 1) + minNum);
                break;
            default:
                return 0;
                break;
        }
    }

    function formatDate(time, type) {
        if(isNaN(time) || time == null || time == '' || time == undefined) {
            return '';
        }
        var tmpDate = new Date(parseInt(time));
        var year = tmpDate.getFullYear();
        var month = addZero(tmpDate.getMonth() + 1);
        var day = addZero(tmpDate.getDate());
        var hours = addZero(tmpDate.getHours());
        var minutes = addZero(tmpDate.getMinutes());
        var seconds = addZero(tmpDate.getSeconds());
        if(type == 'yyyy年mm月dd日') {
            return year + '年' + month + '月' + day + '日';
        } else if(type == 'yyyy-mm-dd') {
            return year + '-' + month + '-' + day;
        } else if(type == 'yyyy-mm') {
            return year + '-' + month;
        } else if(type == 'hh:mm:ss') {
            return hours + ':' + minutes + ':' + seconds;
        } else if(type == 'hh:mm') {
            return hours + ':' + minutes;
        } else if(type == 'yyyy-mm-dd hh:ss') {
            return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes;
        } else if(type == 'yyyy-mm-dd hh:mm:ss') {
            return year + '-' + month + '-' + day + ' ' + '00:00:00';
        } else {
            return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
        }
    }
    function formatTime(time) {
        var tmpDate = new Date();
        var year = tmpDate.getFullYear();
        var month = addZero(tmpDate.getMonth() + 1);
        var day = addZero(tmpDate.getDate());
        return year + '-' + month + '-' + day + ' ' + time;
    }
    function addZero(time) {
        var d = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09']
        if(parseInt(time) < 10) {
            return d[time]
        } else {
            return time
        }
    }

    function getDayStartTime(time) {
        return Date.parse(new Date(formatDate(Date.parse(time), 'yyyy-mm-dd hh:mm:ss'))) / 1000;
    }
</script>
<script type="text/javascript">
	$(document).ready(function() {
    var animationSpeed = 200;
    $('.sidebar-menu').on('click', 'li.has-sub>a', function(e) {
        e.preventDefault();
        var $this = $(this);
        var nextElem = $(this).next();
        if (nextElem.parent("li").is('.active')) {
            nextElem.css('display','block');
            nextElem.slideUp(animationSpeed, function() {
                //收起
                nextElem.parent("li").removeClass("active");
            });
        } else {
            var subUl = $('.sidebar-menu .has-sub');
            subUl.find('ul:visible').slideUp(animationSpeed, function() {
                //收起
                subUl.removeClass("active");
            });
            nextElem.slideDown(animationSpeed, function() {
                //展开
                nextElem.parent("li").addClass("active");
            });
        }
      });
});
</script>
 

<script type="text/javascript">
    const routes = [
        <?php if(is_array($AdminMenu) || $AdminMenu instanceof \think\Collection || $AdminMenu instanceof \think\Paginator): if( count($AdminMenu)==0 ) : echo "" ;else: foreach($AdminMenu as $key=>$v): if($v['route']): ?>
                <?php echo $v['route']; endif; endforeach; endif; else: echo "" ;endif; if(is_array($siteRoutes) || $siteRoutes instanceof \think\Collection || $siteRoutes instanceof \think\Paginator): if( count($siteRoutes)==0 ) : echo "" ;else: foreach($siteRoutes as $key=>$v): ?><?php echo $v; endforeach; endif; else: echo "" ;endif; ?>
    ];
    const router = new VueRouter({
//      mode: 'history',
        base: '/',
        routes
    });
     new Vue({
        router,
        el: '#mipcms',
        data: {
            sideList: [],
            headerList: [],
        },
        watch: {
        },
        mounted() { 
        	this.getSideList();
            this.getHeaderList();      
        },
        methods: {
        	getSideList() {
                 this.$mip.ajax('<?php echo $domain; ?>/addons/ApiAdminAddons/getSideList', {
                }).then(res => {
                    if(res.code == 1) {
                        this.sideList = res.data;
                    }
                });
            },
            getHeaderList() {
                 this.$mip.ajax('<?php echo $domain; ?>/addons/ApiAdminAddons/getHeaderList', {
                }).then(res => {
                    if(res.code == 1) {
                        this.headerList = res.data;
                    }
                });
            },
            loginOut() {
           		this.$mip.ajax('<?php echo $domain; ?>/user/ApiUserUser/loginOut', {
	            }).then(res => {
	                if (res.code == 1) {
	                    this.$Message.error(res.msg);
	                    location.href = '/';
	                }
	            });
	        },
	        editPassword() {
	        	if (this.$route.params.dataId) {
		            this.$router.push({
		                name: 'user/editAccount', params: { mod:'user',dataId: this.$route.params.dataId}
		            });
	        	} else {
		            this.$router.push({
		                name: 'user/editAccount', params: { mod:'user'}
		            });
	        	}
	        }
        }
    });
    
	iview.Message.config({
	    duration: 1.5
	});
</script>



</html>