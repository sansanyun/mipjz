<?php if (!defined('THINK_PATH')) exit(); /*a:0:{}*/ ?>
<li class="li has-sub" :class='{"active":$route.params.mod  == "article"}'>
    <a class="list-link with-sub"><i class="ion-ios-book-outline"></i> 文章
       <div class="list-icon"><i class="triangle-facing-left"></i><i class="triangle-facing-bottom"></i></div>
    </a>
    <ul class="sub-list">
        <li class="sub-item">
            <router-link class="sub-link" :to='"/article/articleList/"'>全部文章</router-link>
        </li>
        <li class="sub-item">
            <router-link class="sub-link" :to='"/article/articlePush/" + ($route.params.dataId && ($route.params.dataId != "undefined")  ? $route.params.dataId : "")'>SEO推送</router-link>
        </li>
        <li class="sub-item">
            <router-link class="sub-link" :to='"/article/articleCategory/"'>分类管理</router-link>
        </li>
        <li class="sub-item">
            <router-link class="sub-link" :to='"/article/articleDiy/"'>自定义字段</router-link>
        </li>
    </ul>
</li>
