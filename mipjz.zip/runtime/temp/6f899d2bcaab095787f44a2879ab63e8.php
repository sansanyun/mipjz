<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:50:"/Users/guuyang/web/wwwroot/mipjz/addons/ad/ad.html";i:1546352879;}*/ ?>
<?php echo $itemInfo['content']; ?>
