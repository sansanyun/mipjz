<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:52:"D:\wwwroot\mipjz\template\default\tag\tagDetail.html";i:1546344004;s:48:"D:\wwwroot\mipjz\template\default\main\main.html";i:1546007770;s:50:"D:\wwwroot\mipjz\template\default\main\header.html";i:1546011586;s:57:"D:\wwwroot\mipjz\template\default\block\article-list.html";i:1546392862;s:53:"D:\wwwroot\mipjz\template\default\block\tags-hot.html";i:1546006454;s:50:"D:\wwwroot\mipjz\template\default\main\footer.html";i:1546006454;}*/ ?>
<!DOCTYPE html>
<html mip>
<head>
    <meta charset="utf-8">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="MobileOptimized" content="width"/>
    <meta name="HandheldFriendly" content="true"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
    <link rel="shortcut icon" href="<?php echo $domainStatic; ?>/favicon.ico" type="image/x-icon" />
    <title><?php echo $mipTitle; ?></title>

    <meta name="keywords" content="<?php echo $mipKeywords; ?>">
    <meta name="description" content="<?php echo $mipDescription; ?>">
    
        <link rel="stylesheet" type="text/css" href="//at.alicdn.com/t/font_wm0lx5dg3606n7b9.css"/>
    <link rel="stylesheet" type="text/css" href="https://c.mipcdn.com/static/v1/mip.css">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/<?php echo $tplName; ?>/css/mipcms.css">
    <style mip-custom>
        .search-form div{
            width: 250px;
        }
        .mipmb-default-search {
            margin-top: -4px;
        }
     .no-data-block {    height: 300px;    padding-top: 80px;}.no-data-block img {    margin: 0 auto;    width: 60px;    position: relative;}.no-data-block p {    margin-top: 15px;    color: #c3d1d6;}.tag-header {    display: flex;    padding-bottom: 15px;    margin-bottom: 15px;    border-bottom: 1px solid #EFEFEF;} .tag-header .tag-img {    border: 1px solid #C3D1D6;    width: 60px;    height: 60px;    text-align: center;    padding-top: 5px;    border-radius: 3px;    margin-right: 15px;}.tag-header .mip-biaoqian {     font-size: 35px;     margin-bottom: 10px;}.tag-header .tag-info-content h2 {    margin-top: 7px;    margin-bottom: 5px;    font-size: 20px;}.tag-header .tag-info-content p {    color: #666;    margin-bottom: 0;}
    </style>
    <link rel="canonical" href="<?php echo $siteUrl; ?>">
</head>
<body>
<?php if($mipInfo["guanfanghaoStatus"]): ?><?php echo $mipInfo['guanfanghaoCambrian']; endif; ?>
    <mip-fixed type="top">
    <div class="mipmb-header mipmb-header-default" id="mip_header">
    <div class="container">
        <div class="menu-warp">
            <div class="logo-text">
                <a data-type="mip" href="<?php echo $domain; ?>" data-title="<?php echo $mipInfo['siteName']; ?>"><?php echo $mipInfo['siteName']; ?></a>
            </div>
            <ul class="mipmb-menu list-unstyled">
                <li class='nav-item <?php if($mod=='index'): ?>active<?php endif; ?>'>
                    <a href="<?php echo $domain; ?>" data-type="mip" data-title="<?php echo $siteInfo['siteName']; ?>" title='首页'>首页</a>
                </li>
                <?php $__think__tag__ = '{"value":"v","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.widget.model.Widget")->getItemListByTag($__think__tag__); if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                <li class="nav-item">
                    <a <?php if($v["target"]): ?>target="_blank"<?php endif; ?> href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <div class="d-none d-lg-block header-search-warp">
                <mip-form class='form-inline search-form' width='350' url="<?php echo $domain; ?>/search" method="get">
                    <div class="d-inline-block pull-left">
                        <input class="form-control" type="text" name="q">
                    </div>
                    <input type="submit" class="d-inline btn btn-primary" value="搜索">
                </mip-form>
            </div>
        </div>
        <div class="d-none d-lg-block float-right">
            <ul class="mipmb-menu list-unstyled">
                <?php if($userInfo["group_id"] == 1): ?>
                <li>
                    <a href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/">后台管理</a>
                </li>
                <?php else: ?>
                <li>
                    <a href="<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/">登录</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

    </mip-fixed>
    <main class="mipcms-main">
      <div class="container">    <div class="row">        <main class="col-lg-8">            <section class="mip-box mip-box-default">                <section class="mip-box-body">                    <div class="tag-header">                        <div class="tag-img">                            <i class="mip-iconfont mip-biaoqian"></i>                        </div>                        <div class="tag-info-content">                            <h2><?php echo $tagInfo['name']; ?></h2>                            <p><?php echo $tagInfo['description']; ?></p>                        </div>                    </div>                     <div class="mipui-widget-media-body mipui-category-list-001">                        <?php $__think__tag__ = '{"value":"v","tagIds":"'.$tagInfo['id'].'","page":"'.$tagInfo['page'].'","limit":"10","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.article.model.Articles")->getItemListByTag($__think__tag__,"list");$pagination = model("app.article.model.Articles")->getItemListByTag($__think__tag__,"pagination"); if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>                            <div class="mipui-category-list-item">
    <div class="item-media">
        <a href="<?php echo $v['url']; ?>" class="item-link" data-type="mip" data-title="<?php echo $v['title']; ?>" title='<?php echo $v['title']; ?>'>
            <?php if($v['firstImg']): ?>
            <mip-img layout="container" alt='<?php echo $v['title']; ?>' src="<?php echo $v['firstImg']; ?>"></mip-img>
            <?php else: ?>
            <mip-img layout="container" src="<?php echo $domainStatic; ?>/<?php echo $assets; ?>/<?php echo $tplName; ?>/images/no-images.jpg" alt='<?php echo $v['title']; ?>'></mip-img>
            <?php endif; ?>
        </a>
    </div>
    <div class="item-content">
        <h4><a href="<?php echo $v['url']; ?>" data-type="mip" data-title="<?php echo $v['title']; ?>" title='<?php echo $v['title']; ?>'><?php echo $v['title']; ?></a></h4>
        <p class="description"><?php echo $v['description']; ?></p>
        <p>
            <span><?php echo date('Y-m-d',$v['publish_time']); ?></span>
        </p>
    </div>
</div>
                        <?php endforeach; endif; else: echo "" ;endif; ?>                    </div>                    <?php echo $pagination; ?>                </section>            </section>        </main>                 <aside class="col-lg-4">            <div class="mip-box">
    <div class="mip-box-heading">
        <h3 class="title">热门<?php echo $mipInfo['tagModelName']; ?></h3>
    </div>
    <div class="mip-box-body">
        <ul class="list-unstyled tags">
            <?php $__think__tag__ = '{"value":"v","orderBy":"relevance_num","limit":"20","key":"index"}';$__think__list__ = "";$__think__list__ = model("app.tag.model.Tags")->getItemListByTag($__think__tag__,"list");$pagination = ""; if(is_array($__think__list__) || $__think__list__ instanceof \think\Collection || $__think__list__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__think__list__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                <li class="m-b-sm"><a href="<?php echo $v['url']; ?>" data-type="mip" data-title="<?php echo $v['name']; ?>" title="<?php echo $v['name']; ?>"><?php echo $v['name']; ?></a></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>
        </aside>    </div></div>
    </main>
    <footer class="mipui-footer">
    <div class="container">
        <?php echo hook("friendlinkHook"); ?>
        <p class="text-center mip-footer">&copy;<?php echo date('Y'); ?> <a data-type="mip" href="<?php echo $domain; ?>" data-title="<?php echo $mipInfo['siteName']; ?>"><?php echo $mipInfo['siteName']; ?></a> <?php echo $mipInfo['icp']; ?><a href="<?php echo $domain; ?>/sitemap.xml">网站地图</a> <br class="visible-xs" /> Powered By <a data-type="mip" data-title='MIPCMS'  href="http://www.mipcms.com" target="_blank">MIPCMS</a><?php echo $mipInfo['statistical']; ?> </p>
    </div>
</footer>
    <mip-fixed type="gototop">
        <mip-gototop></mip-gototop>
    </mip-fixed>
    
    <script src="https://c.mipcdn.com/static/v1/mip.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-stats-baidu/mip-stats-baidu.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-gototop/mip-gototop.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-history/mip-history.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-fixed/mip-fixed.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://c.mipcdn.com/extensions/platform/v1/mip-cambrian/mip-cambrian.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-form/mip-form.js" type="text/javascript" charset="utf-8"></script>
    
</body>
</html>