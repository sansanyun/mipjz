<?php if (!defined('THINK_PATH')) exit(); /*a:0:{}*/ ?>
<style>
	
</style>
<template>
<div>
    <header class="mipcms-container-header">
    <div class="float-left">
        <h4><?php echo $itemName; ?></h4>
    </div>
</header>
<main class="mipcms-container-body" style="height: calc(100% - 50px)">
    <section class="mip-box">
        <section class="mip-box-body" style="min-height: 500px;">
            <h1 class="text-center mt-3">欢迎使用MIPCMS文章标签批量生成插件</h1>
            <p class="text-center mt-3 mb-3">在使用过程中如遇见问题 请加联系QQ：85249417</p>
            
            <p class="text-center mt-3 mb-3">当前待计算文章数：{{allToTal}} 待处理文章数：<span v-text='lastCount'></span></p>
            <div style="width: 400px;margin: 0 auto;" class="text-center ">
                <i-Progress :percent="keywordTagsScale"></i-Progress>
                <button class="btn btn-primary btn-sm mt-3 mb-3" @click='keywordTagsMidSubmit()' :disabled='keywordTagsIsSubmit' v-text='keywordTagsSubmitName'></button>
            </div>
            
             
        </section>
    </section>
     
</main>
</div>
</template>

<script>
    export default {
     data () {
       return {
          	 keywordTagsModal: false,
            keywordTagsScale: 0,
            keywordTagsSubmitName: '生成标签',
            keywordTagsIsSubmit: false,
            countList: [],
            lastCount: 0,
            allToTal: 0,
       }
     },
     watch: {
            
        },
        mounted() {
            this.keywordTags();
        },
        methods: {
            //标签生成
            keywordTags() {
                this.keywordTagsModal = true;
                this.keywordTagsSubmitName = '正在计算中';
                this.keywordTagsIsSubmit = true;
                //查询无标签的文章ids
                this.keywordTagsGet();
            },
            //确认
            keywordTagsMidSubmit() {
                this.keywordTagsScale = 0;
                this.keywordTagsSubmitName = '正在生成...';
                this.keywordTagsIsSubmit = true;
                this.keywordTagsSave(0);
            },
            //查询无标签的文章ids
            keywordTagsGet() {
                this.$mip.ajax('<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/ApiAdminTagKeyword/searchNotagsItem', {
                }).then(res => {
                    if (res.code == 1) {
                        var countList = res.data.itemList;
                        this.allToTal = res.data.allTotal;
                        if (countList && countList.length) {
                            this.keywordTagsIsSubmit = false;
                            this.keywordTagsSubmitName = '批量生成'
                            this.countList = countList;
                            this.lastCount = this.countList.length;
                        } else {
                            this.keywordTagsSubmitName = '批量生成'
                            this.keywordTagsIsSubmit = true;
                        }
                        
                    }
                });
            },
            
            keywordTagsSave(index) {
                if (!this.countList && !this.countList.length) {
                    return false;
                }
                
                var keywordTagsScale = parseInt(index / (parseInt(this.countList.length)) * 100);
                if (keywordTagsScale < 100) {
                    this.keywordTagsScale = keywordTagsScale;
                } else {
                    this.keywordTagsScale = 100;
                }
                if (parseInt(index) + 1 > this.countList.length) {
                    this.keywordTagsSubmitName = '批量生成'
                    this.keywordTagsIsSubmit = true;
                    this.$Message.success('操作完毕');
                    return false;
                }
                            
                //获取内容
                this.$mip.ajax('<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/ApiAdminTagKeyword/getItemInfoById', {
                    id: this.countList[index],
                }).then(res => {
                    if(res.code == 1) {
                        var countList = res.data.itemList;
                        var content = countList[0]['content'].replace(/\s/g,"");
                        if (!countList[0]['content'].replace(/\s/g,"")) {
                            content = countList[0]['title'];
                        }
                   		this.$mip.ajax('<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/ApiAdminTagKeyword/keyword', {
                            title: countList[0]['title'],
                            content: content,
                        }).then(res => {
                            if(res.code == 1) {
                                this.lastCount = parseInt(this.countList.length - (parseInt(index) + 1));
                                var tagsList = res.data.items;
                                var tempTagsList = [];
                                if (tagsList && tagsList.length) {
                                    for (var i = 0; i < tagsList.length; i++) {
                                        if (i < 5) {
                                            tempTagsList.push(tagsList[i]['tag']);
                                        }
                                    }
                                    tempTagsList = tempTagsList.join(',');
                                }
                                if (!tagsList || !tagsList.length) {
                                	tempTagsList = '';
                                }
                                this.$mip.ajax('<?php echo $domain; ?>/<?php echo \think\Config::get('admin'); ?>/ApiAdminTagKeyword/keywordTagsAdd', {
                                    tags: tempTagsList,
                                    id: countList[0]['content_id'],
                                }).then(res => {
                                    if(res.code == 1) {
                                        this.keywordTagsSave(index + 1); 
                                    }
                                });  
                                
                            }
                        });
                    }
                });
                        
            },
        }
    }
</script>
