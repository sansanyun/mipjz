<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:62:"/Users/guuyang/web/wwwroot/mipjz/app/install/view/install.html";i:1546333030;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
    <title>欢迎使用MIPCMS内容管理系统</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/iview@2.7.4/dist/styles/iview.css">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    
      <style type="text/css">
        body {
            background-color: #eff3f6;
        }
        .ivu-icon.ivu-icon-close-circled {
            color: #E53939;
        }
        .box.box-default .box-body{
            padding: 10px;
            background-color: #FFFFFF;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div id="install" style="width: 600px;margin: 0 auto;padding-top: 20px;">
        <h2 style="text-align: center;line-height: 70px;">欢迎使用MIPCMS内容管理系统</h2>
       
        <i-form ref="form" :rules="rules" :model="form" :label-width="100">
            <div class="box box-default">
                  <div class="box-body">
                <h3 style="text-align: center;line-height: 50px;">环境检测</h3>
                      <div class="row">
                        <div class="col-md-6"><Form-item label="当前PHP版本"><span><?php echo $data['phpversion']; ?></span>（建议7.0）</Form-item></div>
                        <div class="col-md-6"><Form-item label="当前环境系统"><span><?php echo $data['os']; ?></span></Form-item></div>
                        <div class="col-md-6"><Form-item label="pdo"><span><?php echo $data['pdo']; ?></span></Form-item></div>
                        <div class="col-md-6"><Form-item label="pdo_mysql"><span><?php echo $data['pdo_mysql']; ?></span></Form-item></div>
                        <div class="col-md-6"><Form-item label="curl"><span><?php echo $data['curl']; ?></span></Form-item></div>
                        <div class="col-md-6"><Form-item label="allow_url_fopen"><span><?php echo $data['allow_url_fopen']; ?></span></Form-item></div>
                        <div class="col-md-6"><Form-item label="file_get_contents"><span><?php echo $data['file_get_contents']; ?></span></Form-item></div>
    
                        <div class="col-md-6"><Form-item label="runtime"><span><?php echo !empty($data['checklist']['cache']['w'])?'<Icon type="checkmark-circled"></Icon> 可写 ' : '<Icon type="close-circled"></Icon></i> 不可写'; ?></span></Form-item></div>
                        <div class="col-md-6"><Form-item label="public/install"><span><?php echo !empty($data['checklist']['install']['w'])?'<Icon type="checkmark-circled"></Icon> 可写 ' : '<Icon type="close-circled"></Icon></i> 不可写'; ?></span></Form-item></div>
                        <div class="col-md-6"><Form-item label="app"><span><?php echo !empty($data['checklist']['config']['w'])?'<Icon type="checkmark-circled"></Icon> 可写' : '<Icon type="close-circled"></Icon> 不可写'; ?></span></Form-item></div>
                    </div>
                  </div>
            </div>

             <div style="background: #fff;padding: 10px;border-radius: 5px;margin-top: 15px;">
                <h3 style="text-align: center;line-height: 50px;">数据库信息填写</h3>
                <p style="text-align: center;">注：系统不会自动创建数据库</p>
            
                 <Form-item label="目录运行URL">
                    <i-input v-model="form.installAddress" placeholder="用于二级目录安装，不是目录安装，请留空"></i-input>
                    <p>例如：http://www.test.com/news/</p>
                    <p>末尾请加反斜杠，非目录安装站点，请勿填写</p>
                  </Form-item>
                 <Form-item label="数据库地址" prop="dbhost">
                    <i-input v-model="form.dbhost"></i-input>
                  </Form-item>
                  <Form-item label="数据库端口" prop="dbport">
                    <i-input v-model="form.dbport"></i-input>
                  </Form-item>
                  <Form-item label="数据库 名称" prop="dbname">
                    <i-input v-model="form.dbname" placeholder="链接数据库的名称"></i-input>
                  </Form-item>
                  <Form-item label="数据库 用户" prop="dbuser">
                    <i-input v-model="form.dbuser" placeholder="链接数据库的用户名"></i-input>
                  </Form-item>
                  <Form-item label="数据库 密码">
                    <i-input type="password" v-model="form.dbpw" placeholder="链接数据库的密码"></i-input>
                  </Form-item>
                  <Form-item label="数据表前缀" prop="dbprefix">
                    <i-input v-model="form.dbprefix"></i-input>
                  </Form-item>
                  <hr />
                    <h3 style="text-align: center;line-height: 50px;">管理员信息填写</h3>
                  <Form-item label="管理账户" prop="username">
                    <i-input v-model="form.username"></i-input>
                  </Form-item>
                  <Form-item label="管理密码" prop="password">
                    <i-input type='password' v-model="form.password"></i-input>
                  </Form-item>
                  <Form-item label="重复密码" prop="rpassword">
                    <i-input type='password' v-model="form.rpassword"></i-input>
                  </Form-item>
                  
             </div>
                  <div style="text-align: center;padding:40px;">
                    <I-button type="primary" @click="submitForm('form')">立即安装</I-button>
                  </div>
            </i-form>
       

  </div>
</body>
<script type="text/javascript">
    var mipGlobal = {
        domain: '',
        rewrite: '/index.php?s=',
    }
</script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/vue"></script>
<script type="text/javascript" src="https://cdn.staticfile.org/axios/0.15.3/axios.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/iview"></script>
<script src="https://cdn.staticfile.org/blueimp-md5/2.7.0/js/md5.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
var mip = {
    ajax(url, param) {
        return new Promise(function(resolve, reject) {
             
            axios.post(url, param).then(function(res) {
                if(res.status == 200) {
                    if(res.data.code == undefined) {
                        iview.Message.error('请求无效');
                        return false;
                    }
                    if(res.data.code != 200 && res.data.code != 1 && res.data.code != -1) {
                        iview.Message.error(res.data.msg + ' 错误代码:' + res.data.code);
                    } else {
                        if (res.data.code == -1) {
                            iview.Message.error(res.data.msg);
                        }
                    }
                    resolve(res.data);
                } else {
                    iview.Message.error('系统错误');
                }
            }, function(err) {
                iview.Message.error('系统错误，错误代码：' + err.response.status);
            })
        });
    },
}

Vue.prototype.$mip = mip;
</script>
<script type="text/javascript">
        new Vue({
      el: "#install",
      data: function(){
        return {
             form: {
                domain: '<?php echo \think\Request::instance()->server('HTTP_HOST'); ?>',
                installAddress: '',
                dbhost: "127.0.0.1",
                dbport: "3306",
                dbuser: "",
                dbpw: "",
                dbname: "",
                dbprefix: "mip_",
                },
            rules: {
                dbhost: [
                    { required: true, message: "必填项", trigger: "blur" },
                ],
                dbport: [
                    { required: true, message: "必填项", trigger: "blur" },
                ],
                dbuser: [
                    { required: true, message: "必填项", trigger: "blur" },
                ],
                dbpw: [
                    { required: true, message: "必填项", trigger: "blur" },
                ],
                dbname: [
                    { required: true, message: "必填项", trigger: "blur" },
                ],
                username: [
                    { required: true, message: "必填项", trigger: "blur" },
                ],
                password: [
                    { required: true, message: "必填项", trigger: "blur" },
                    { min: 5, max: 25, message: '长度在 5 到25 个字符', trigger: 'blur' }
                ],
                rpassword: [
                    { required: true, message: "必填项", trigger: "blur" },
                    { min: 5, max: 25, message: '长度在 5 到25 个字符', trigger: 'blur' }
                ],
            }
        }
      },
      methods: {
        submitForm:function(formName) {
            this.$refs[formName].validate((valid) => {
              if (valid) {
                        var _this = this
                        this.$mip.ajax('index.php?s=/install/installPost', {
                            "installAddress" : this.form.installAddress,
                            "domain" : _this.form.domain,
                            "dbhost": this.form.dbhost,
                            "dbport": this.form.dbport,
                            "dbuser": this.form.dbuser,
                            "dbpw": this.form.dbpw,
                            "dbname": this.form.dbname,
                            "dbprefix": _this.form.dbprefix,
                            "username": _this.form.username,
                            "password": md5(_this.form.password),
                            "rpassword": md5(_this.form.rpassword),
                        }).then(function (res) {
                            if (res.code == 1) {
                                if (res.data == 1) {
                                   _this.$mip.ajax('index.php?s=/install/installPostOne', {
                                       "installAddress" : _this.form.installAddress,
                                       "domain" : _this.form.domain,
                                        "dbhost": _this.form.dbhost,
                                        "dbport": _this.form.dbport,
                                        "dbuser": _this.form.dbuser,
                                        "dbpw": _this.form.dbpw,
                                        "dbname": _this.form.dbname,
                                        "dbprefix": _this.form.dbprefix,
                                        "username": _this.form.username,
                                        "password": md5(_this.form.password),
                                        "rpassword": md5(_this.form.rpassword),
                                    }).then(function (res) {
                                        if (res.code == 1) {
                                           location.href= _this.form.installAddress;
                                        }
                                    });
                                }
                            }
                        });
              } else {
                return false;
              }
            });
          },
        }
    });
</script>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?3155433929be1afd6cef849b9709d4d7";
  var s = document.getElementsByTagName("script")[0];
  s.parentNode.insertBefore(hm, s);
})();
</script>
</html>