<?php if (!defined('THINK_PATH')) exit(); /*a:0:{}*/ ?>
<style>
	
@font-face {font-family: "iconfont";
  src: url('//at.alicdn.com/t/font_721249_sm5o41glol.eot?t=1529984012182'); /* IE9*/
  src: url('//at.alicdn.com/t/font_721249_sm5o41glol.eot?t=1529984012182#iefix') format('embedded-opentype'), /* IE6-IE8 */
  url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAd8AAsAAAAACwwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADMAAABCsP6z7U9TLzIAAAE8AAAARAAAAFZXQkg/Y21hcAAAAYAAAAB0AAAByJtGz3FnbHlmAAAB9AAAA2kAAASIvoUUr2hlYWQAAAVgAAAALwAAADYRzu3BaGhlYQAABZAAAAAcAAAAJAfeA4dobXR4AAAFrAAAABcAAAAYF9EAAGxvY2EAAAXEAAAADgAAAA4EFgKmbWF4cAAABdQAAAAfAAAAIAEYAGtuYW1lAAAF9AAAAUUAAAJtPlT+fXBvc3QAAAc8AAAAPwAAAFBSvzkReJxjYGRgYOBikGPQYWB0cfMJYeBgYGGAAJAMY05meiJQDMoDyrGAaQ4gZoOIAgCKIwNPAHicY2Bk/sE4gYGVgYOpk+kMAwNDP4RmfM1gxMjBwMDEwMrMgBUEpLmmMDgwVDwLZW7438AQw9zAcAUozAiSAwAsnw0VeJzFkbENgDAMBM8EEAIa9mASRMsqiIJ5vQa8EyiYgI8uyr8cOYqBBkhiFjXYiRHalVrOE33Oaxb5kY5K58PxwSffrkvp170yVb8rXJNvqpu1/Cb7r/VXY97Xx8Ucjgc90SlE7kNBv4dPhZiVbwXSDdxYGQ94nFVTz4/bRBSez9PY2XVixxP/yk/HdhJv2MbJOolzYJtFFCRYAdqlBwQsqMC55bCHXpCaCxKHInHivEKoqEWIigNCqIeKK/9AJSrBih44rQRHtJkyTrpoa8289/nNe5/em/eG5Ah5ckzvU5eUyQbZIi+RPUIgbyLQpAb8aBxLm7D8nOWYGo3CyFfCIKaX4ASyaSfpuOvIiqxDQxMjP0mjWIowGc+k55HYDaBSq15hnTqjX2DdjZqf8l3pK1heWNdnff7qxR0zaZXzNwqMVRi7lZdzubwkXdA1XHPstdzausy/zulV677XkzwUKlH1tbeLrRr74LPx9UbHWQPmc5RrLe2bHaNqiPVJ1S6zilIq5t1qMWybuPFYdcuFRvdPIj4qar1In9A+mZCXyT4ha4gRhcOtQFY0NDCajNPpDKPh1qgJB7apQA4i4XMJobW0JFOk407Qjbpj4ZjYjvCRI3EDy7uIYtBH3PM+7D+sxiVNG+TlfNP4Ldiv4tiy+Imd2rxV8wboNXEcHoQohYtapc86HdZPYqPTCSdexY5fiG21AYrjZg8GK/hsd1fVc+sqAod7GcffloU/6tvl7W3vDZ+3QkHUPvjBNKKPIsNcqvavsN2dwWDHVQuEZD3+nP5CD4lKHBKSEbkseuwH3XEqemabMj2HoyWe+k2YctkX92PMkP05hgYEsmWYdtboiTHuhtLv/K2irhdxJ5Pn8HX+0xK/UtBLJwvW6gG9lnSy1Kf/5NdVRTpRVCFDvVIqVXR+S6/oYv0sNiAE74gAurcKPL3X3KTfqsrpvSyG7inqqpfzC4TOiUFqoiKCbqDAmRoiU19kbDhThCL1bA4tUcomjKzXGhQjFP0zkCYOpI+Tm1v8sD9C2pPmvRTpc/y9B2DFucZAmHYk7PONKY6KDKg3Xm+gTvcHA34YJ9wV7uIYf6UxJ7iqMabxByLs6srOj5gmbaBer/PH2ezlRb4/0rv0XYEMUiVdkpAXyZvkfZH52VOiZyDSsAK5MDM5oxnE6Tk89bNCzkoVY2fKoZ+VNcteoW3RMGMQtQsOxMx1267LnlH4kgvAnhXXFu+0h8CwLd1eaZctvmcu4DJpn7k3/3eUDjKOtsu/W+m7WOk7YiPDuHKGuKBZyE9p/20PTx9lJNLtJdXDp3HkP6Fmx3UAAAB4nGNgZGBgAGKulV/k4vltvjJwszCAwPXwqzwI+r8OCwNzA5DLwcAEEgUAEWEJUAB4nGNgZGBgbvjfwBDDwgACQJKRARWwAQBHDAJveJxjYWBgYH7JwMDCgMDMLxgYABVTAegAAAAAAAB2APIBXAG0AkQAAHicY2BkYGBgY4hn4GAAASYg5gJCBob/YD4DABLrAYQAeJxlj01OwzAQhV/6B6QSqqhgh+QFYgEo/RGrblhUavdddN+mTpsqiSPHrdQDcB6OwAk4AtyAO/BIJ5s2lsffvHljTwDc4Acejt8t95E9XDI7cg0XuBeuU38QbpBfhJto41W4Rf1N2MczpsJtdGF5g9e4YvaEd2EPHXwI13CNT+E69S/hBvlbuIk7/Aq30PHqwj7mXle4jUcv9sdWL5xeqeVBxaHJIpM5v4KZXu+Sha3S6pxrW8QmU4OgX0lTnWlb3VPs10PnIhVZk6oJqzpJjMqt2erQBRvn8lGvF4kehCblWGP+tsYCjnEFhSUOjDFCGGSIyujoO1Vm9K+xQ8Jee1Y9zed0WxTU/3OFAQL0z1xTurLSeTpPgT1fG1J1dCtuy56UNJFezUkSskJe1rZUQuoBNmVXjhF6XNGJPyhnSP8ACVpuyAAAAHicY2BigAAuBuyAjZGJkZmRhZGVkY2RnYGxgiMpMzG/MDMxjz0vNbMoPy+drTgjv7QylSUns7iEgQEAyZgLVQA=') format('woff'),
  url('//at.alicdn.com/t/font_721249_sm5o41glol.ttf?t=1529984012182') format('truetype'), /* chrome, firefox, opera, Safari, Android, iOS 4.2+*/
  url('//at.alicdn.com/t/font_721249_sm5o41glol.svg?t=1529984012182#iconfont') format('svg'); /* iOS 4.1- */
}

.iconfont {
  font-family:"iconfont" !important;
  font-size:16px;
  font-style:normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.icon-biaoqian:before { content: "\e60b"; }

.icon-neirong:before { content: "\e655"; }

.icon-shouye:before { content: "\e611"; }

.icon-list:before { content: "\e600"; }

</style>
<template>
<div>
    <header class="mipcms-container-header clearfix">
        <div class="header-group">
            <h4 class="title">插件</h4> <h5 class="sub-title">静态页面生成（使用该插件，蜘蛛统计将失效）</h5>
        </div>
    </header>
    <main class="mipcms-container-body" style="height: calc(100% - 50px)">
            <div class="row">
            	<div class="col-3">
		            <section class="mip-box">
		                <section class="mip-box-body text-center">
		                	<p>
		                		<i class="iconfont icon-shouye" style="color: #2d8cf0;font-size: 40px;text-align: center;"></i>
							</p>
							<p>首页</p>
		                     <button class="ivu-btn ivu-btn-primary" @click="indexAction">首页生成</button>
		                </section>
		            </section>
            	</div>
            	<div class="col-3">
		            <section class="mip-box">
		                <section class="mip-box-body text-center">
		                	<p>
		                		<i class="iconfont icon-list" style="color: #2d8cf0;font-size: 40px;text-align: center;"></i>
							</p>
							<p>分类页</p>
		                     <button class="ivu-btn ivu-btn-primary" @click="categoryAction">分类生成</button>
		                </section>
		            </section>
            	</div>
            	<div class="col-3">
		            <section class="mip-box">
		                <section class="mip-box-body text-center">
		                	<p>
		                		<i class="iconfont icon-neirong" style="color: #2d8cf0;font-size: 40px;text-align: center;"></i>
							</p>
							<p>内容页</p>
		                     <button class="ivu-btn ivu-btn-primary" @click="detailClick">文章生成</button>
		                </section>
		            </section>
            	</div>
            	<div class="col-3">
		            <section class="mip-box">
		                <section class="mip-box-body text-center">
		                	<p>
		                		<i class="iconfont icon-biaoqian" style="color: #2d8cf0;font-size: 40px;text-align: center;"></i>
							</p>
							<p>标签页</p>
		                     <button class="ivu-btn ivu-btn-primary" @click="tagClick">标签生成</button>
		                </section>
		            </section>
            	</div>
            </div>
         
    </main>   
   
    <Modal title='批量生成' v-model="htmlModal" width="360" v-cloak>
        <i-form :label-width="80">
            <Form-Item label="进度">
                <i-Progress :percent="scale"></i-Progress>
            </Form-Item>
        </i-form>

        <span slot="footer" class="dialog-footer">
            <i-button @click="htmlModal = false">取 消</i-button>
            <i-button type="primary" @click="detailAction(0)">点击开始</i-button>
        </span>
    </Modal>
   
    <Modal title='批量生成' v-model="tagModal" width="360" v-cloak>
        <i-form :label-width="80">
            <Form-Item label="进度">
                <i-Progress :percent="scale"></i-Progress>
            </Form-Item>
        </i-form>

        <span slot="footer" class="dialog-footer">
            <i-button @click="tagModal = false">取 消</i-button>
            <i-button type="primary" @click="tagAction(0)">点击开始</i-button>
        </span>
    </Modal>
   
</div>
</template>

<script>
    export default {
     data () {
       return {
            htmlModal: false,
 			scale: 0,
 			count: 0,
			id: 0,
			
			tagModal: false,
       }
    },
        watch: {
        },
        mounted() {
        },
        methods: {
        	indexAction() {
                this.$mip.ajax('<?php echo $domain; ?>/html/ApiAdminHtml/index', {

                }).then(res => {
                    if(res.code == 1) {
                 		this.$Message.success('操作成功');
                    }
                });
        	},
        	categoryAction() {
                this.$mip.ajax('<?php echo $domain; ?>/html/ApiAdminHtml/category', {

                }).then(res => {
                    if(res.code == 1) {
                 		this.$Message.success('操作成功');
                    }
                });
        	},
        	detailClick() {
        		this.scale = 0;
        		this.getItemInfo();
        		this.htmlModal = true;
        	},
        	detailAction(index) {
        		if (this.id == 0) {
        			this.$Message.error('没有内容可生成');
        			return false;
        		}
        		
                var scale = parseInt(index / (parseInt(this.count)) * 100);
            	if (scale < 100) {
	                this.scale = scale;
	            } else {
	                this.scale = 100;
	            }
                this.$mip.ajax('<?php echo $domain; ?>/html/ApiAdminHtml/detail', {
					id: this.id,
                }).then(res => {
                    if(res.code == 1) {
                    	if (res.data) {
                    		this.id = res.data;
                    		this.detailAction(index+1);
                    	} else {
                 			this.$Message.success('操作成功');
                 			this.htmlModal = false;
                    	}
                    }
                });
        	},
        	getItemInfo() {
                this.$mip.ajax('<?php echo $domain; ?>/html/ApiAdminHtml/getItemInfo', {
                }).then(res => {
                    if(res.code == 1) {
                    	if (res.data) {
                    		this.id = res.msg;
                    		this.count = res.data;
                    	} else {
                    		this.id = 0;
                    	}
                    }
                });
        	},
        	
        	//tag
        	
        	tagClick() {
        		this.scale = 0;
        		this.getTagInfo();
        		this.tagModal = true;
        	},
        	tagAction(index) {
        		if (this.id == 0) {
        			this.$Message.error('没有标签可生成');
        			return false;
        		}
        		
                var scale = parseInt(index / (parseInt(this.count)) * 100);
            	if (scale < 100) {
	                this.scale = scale;
	            } else {
	                this.scale = 100;
	            }
                this.$mip.ajax('<?php echo $domain; ?>/html/ApiAdminHtml/tag', {
					id: this.id,
                }).then(res => {
                    if(res.code == 1) {
                    	if (res.data) {
                    		this.id = res.data;
                    		this.tagAction(index+1);
                    	} else {
                 			this.$Message.success('操作成功');
                 			this.tagModal = false;
                    	}
                    }
                });
        	},
        	getTagInfo() {
                this.$mip.ajax('<?php echo $domain; ?>/html/ApiAdminHtml/getTagInfo', {
                }).then(res => {
                    if(res.code == 1) {
                    	if (res.data) {
                    		this.id = res.msg;
                    		this.count = res.data;
                    	} else {
                    		this.id = 0;
                    	}
                    }
                });
        	},
        	
        	
        	
        	
        	
        	
        	
        	
        }
    }
</script>
