<?php
//000000000000
 exit();?>
a:2:{s:8:"autoload";b:1;s:5:"hooks";a:4:{s:6:"adHook";a:1:{i:0;s:2:"ad";}s:8:"htmlHook";a:1:{i:0;s:5:"clear";}s:14:"friendlinkHook";a:1:{i:0;s:10:"friendlink";}s:10:"spiderHook";a:1:{i:0;s:6:"spider";}}}