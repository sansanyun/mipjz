<?php
//000000000000
 exit();?>
a:4:{s:6:"adHook";a:1:{i:0;s:13:"\addons\ad\Ad";}s:8:"htmlHook";a:1:{i:0;s:19:"\addons\clear\Clear";}s:14:"friendlinkHook";a:1:{i:0;s:29:"\addons\friendlink\Friendlink";}s:10:"spiderHook";a:1:{i:0;s:21:"\addons\spider\Spider";}}